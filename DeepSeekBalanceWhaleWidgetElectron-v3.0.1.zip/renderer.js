'use strict'

// ===================================================================
//  DeepSeek 小鲸鱼余额挂件 —— 渲染进程 (3.0.1)
//  严格 1:1 复刻原版 DSH 插件 whale-balance.mjs 的 WIDGET_JS：
//  拖拽 / 四边四分之一自吸附 / 左镜像+文字直读 / Q弹 / 调大小记忆
//  / 余额滚动动画 / 60s自动刷新 / 点击刷新 / 状态机
//  仅把数据源换为 IPC。常驻必要的修复：
//   · 点击 force 跳过缓存 + busy 补刷
//   · 拖拽坐标跳变容错（防游戏/高 DPI 误拖带跑）
// ===================================================================

const api = window.whaleApi
const $ = s => document.querySelector(s)

const MIN_SCALE = 0.6
const MAX_SCALE = 1.4
const STEP = 0.1
const CLICK_SQ = 9
const REFRESH_MS = 60000
const CHANGE_MS = 900
const ANIM_MS = 700
const BASE = 196
const clampScale = s => Math.max(MIN_SCALE, Math.min(MAX_SCALE, Math.round(s * 10) / 10))

const state = {
  scale: 1,
  h: 'right', v: 'bottom', hOff: 0, vOff: 0,
  x: 0, y: 0, w: BASE,
  screen: { w: 1280, h: 800, ox: 0, oy: 0 },
  balance: null, currency: null, status: 'loading', message: '',
}
let busy = false, settleTimer = null, drag = null, shown = null, animId = null
let pendingManual = false

const $root = $('#root')

const css = [
  '.wd-root{position:relative;width:100%;height:100%;overflow:hidden;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;z-index:9999;font-family:inherit}',
  '.wd-root.d-left{transform:scaleX(-1)}',
  '.wd-root.d-drag{cursor:grabbing}',
  '.wd-body{position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:50% 100%;transition:transform .22s cubic-bezier(.34,1.56,.64,1)}',
  '.wd-img{position:absolute;left:0;top:0;width:100%;height:100%;display:block;pointer-events:none;-webkit-user-drag:none;user-select:none}',
  '.wd-text{position:absolute;left:44.346%;top:25.5%;transform:translate(-50%,-50%);text-align:center;color:#536ba9;line-height:1.18;white-space:nowrap;pointer-events:none;--u:calc(var(--w)/1026);transition:transform .3s ease}',
  '.wd-root.d-left .wd-text{transform:translate(-50%,-50%) scaleX(-1)}',
  '.wd-label{font-size:calc(var(--u)*68);font-weight:600;letter-spacing:.06em}',
  '.wd-amount{font-size:calc(var(--u)*119);font-weight:800;line-height:1.05}',
  '.wd-hint{font-size:calc(var(--u)*54);color:#9fb0d9;letter-spacing:.02em}',
  '.wd-size{position:absolute;top:4px;right:4px;display:flex;gap:4px;opacity:0;transition:opacity .15s ease;z-index:2}',
  '.wd-root:hover .wd-size{opacity:1}',
  '.wd-size button{width:20px;height:20px;border:none;border-radius:50%;background:rgba(83,107,169,.85);color:#fff;font-size:13px;line-height:1;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;user-select:none}',
  '.wd-size button:hover{background:#536ba9}',
].join('\n')
document.head.appendChild(Object.assign(document.createElement('style'), { textContent: css }))
$root.className = 'wd-root'

const body = document.createElement('div')
body.className = 'wd-body'
const img = document.createElement('img')
img.className = 'wd-img'; img.draggable = false; img.alt = 'DeepSeek 余额'

const sizeBox = document.createElement('div')
sizeBox.className = 'wd-size'
function makeBtn(text, title, delta) {
  const b = document.createElement('button')
  b.type = 'button'; b.textContent = text; b.title = title
  b.addEventListener('pointerdown', e => e.stopPropagation())
  b.addEventListener('click', e => { e.stopPropagation(); adjust(delta) })
  return b
}
sizeBox.appendChild(makeBtn('−', '缩小', -STEP))
sizeBox.appendChild(makeBtn('+', '放大', STEP))

const textBox = document.createElement('div')
textBox.className = 'wd-text'
const labelEl = document.createElement('div'); labelEl.className = 'wd-label'; labelEl.textContent = 'DeepSeek 余额'
const amountEl = document.createElement('div'); amountEl.className = 'wd-amount'
const hintEl = document.createElement('div'); hintEl.className = 'wd-hint'
textBox.appendChild(labelEl); textBox.appendChild(amountEl); textBox.appendChild(hintEl)

body.appendChild(img); body.appendChild(sizeBox); body.appendChild(textBox)
$root.appendChild(body)

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v) }
function fmt(balance, currency) {
  const num = Number(balance)
  const fixed = isFinite(num) ? num.toFixed(2) : '--'
  return currency === 'CNY' ? '¥ ' + fixed : fixed + ' ' + currency
}
function animateAmount(from, to, currency, duration) {
  if (animId) cancelAnimationFrame(animId)
  if (from === null || !isFinite(from)) from = to
  if (from === to) { shown = to; amountEl.textContent = fmt(to, currency); return }
  let t0 = null
  function step(ts) {
    if (t0 === null) t0 = ts
    const t = Math.min(1, (ts - t0) / duration)
    const eased = 1 - Math.pow(1 - t, 3)
    amountEl.textContent = fmt(from + (to - from) * eased, currency)
    if (t < 1) animId = requestAnimationFrame(step)
    else { animId = null; shown = to; amountEl.textContent = fmt(to, currency) }
  }
  animId = requestAnimationFrame(step)
}
function render() {
  let amount, hint
  if (state.status === 'loading') { amount = shown !== null ? fmt(shown, state.currency) : '…'; hint = '加载中…' }
  else if (state.status === 'error') { amount = shown !== null ? fmt(shown, state.currency) : '--'; hint = state.message ? state.message.slice(0, 14) : '获取失败 · 点击重试' }
  else { amount = shown !== null ? fmt(shown, state.currency) : (state.balance !== null ? fmt(state.balance, state.currency) : '--'); hint = state.status === 'changing' ? '加载中…' : '点击刷新' }
  amountEl.textContent = amount
  hintEl.textContent = hint
}

async function reflectWin(animate) {
  const { ox, oy } = state.screen
  let x = clamp(state.x, ox, ox + state.screen.w - state.w)
  let y = clamp(state.y, oy, oy + state.screen.h - state.w)
  if (state.h === 'right') x = ox + state.screen.w - state.w - state.hOff
  else if (state.h === 'left') x = ox + state.hOff
  if (state.v === 'bottom') y = oy + state.screen.h - state.w - state.vOff
  else if (state.v === 'top') y = oy + state.vOff
  state.x = x; state.y = y
  const mirror = state.h === 'left'
  $root.classList.toggle('d-left', mirror)
  if (api) await api.moveWindow({ x: Math.round(x), y: Math.round(y), animate: !!animate }).catch(() => {})
}

async function applyScale(next) {
  const s = clampScale(next)
  if (s === state.scale) return
  state.scale = s
  const w = Math.round(BASE * s)
  state.w = w
  $root.style.setProperty('--w', w + 'px')
  if (api) { await api.setWinSize({ w, h: w }).catch(() => {}) }
  await reflectWin(false)
  if (api) api.setSize(s).catch(() => {})
}
function adjust(delta) { applyScale(state.scale + delta) }

async function refresh(manual) {
  if (busy) { if (manual) pendingManual = true; return }
  busy = true
  if (manual || state.balance === null) { state.status = 'loading'; render() }
  try {
    const data = await api.getBalance(!!manual)
    if (!data) throw new Error('no data')
    if (data.ok) {
      const nb = Number(data.totalBalance)
      const nc = String(data.currency || 'CNY')
      const changed = state.balance !== null && (nb !== state.balance || nc !== state.currency)
      const currencyChanged = state.currency !== null && nc !== state.currency
      state.balance = nb; state.currency = nc; state.message = ''
      if (changed && !currencyChanged) {
        if (!manual) {
          state.status = 'changing'
          animateAmount(shown, nb, nc, ANIM_MS)
          if (settleTimer) clearTimeout(settleTimer)
          settleTimer = setTimeout(() => { settleTimer = null; if (state.status === 'changing') { state.status = 'ok'; render() } }, CHANGE_MS)
        } else {
          animateAmount(shown, nb, nc, ANIM_MS); state.status = 'ok'; render()
        }
      } else {
        if (animId === null) shown = nb
        state.status = 'ok'; render()
      }
    } else {
      state.status = 'error'
      state.message = (data && data.error) ? String(data.error) : '获取失败'
      render()
    }
  } catch (e) { state.status = 'error'; state.message = '获取失败'; render() }
  finally {
    busy = false
    if (pendingManual) { pendingManual = false; refresh(true) }
  }
}

const SQUISH = 'scaleY(0.88) scaleX(1.05)'
function pressDown() { body.style.transform = SQUISH }
function pressUp() { body.style.transform = 'scaleY(1) scaleX(1)' }

function onPointerDown(e) {
  if (e.button !== 0) return
  if (e.target.closest('.wd-size')) return
  try { body.setPointerCapture(e.pointerId) } catch (err) {}
  drag = { active: true, sx: e.screenX, sy: e.screenY, lx: e.screenX, ly: e.screenY, winX: state.x, winY: state.y, moved: false }
  $root.classList.add('d-drag')
  pressDown()
}
function onPointerMove(e) {
  if (!drag || !drag.active) return
  const MAX_DELTA = (state.screen.w * 0.6)
  const dlx = e.screenX - drag.lx
  const dly = e.screenY - drag.ly
  if (Math.abs(dlx) > MAX_DELTA || Math.abs(dly) > MAX_DELTA) {
    // 环境坐标跳变（游戏/高 DPI 抢焦点）：重置整个拖拽基准到当前合理位置，
    // 既避免把"点击"误判成拖动带走窗口，也避免后续正常移动被继续误判。
    // 以当前窗口位置为新基准，使跳变后的正常拖动仍能工作。
    drag.sx = e.screenX; drag.sy = e.screenY
    drag.lx = e.screenX; drag.ly = e.screenY
    drag.winX = state.x; drag.winY = state.y
    return
  }
  const dx = e.screenX - drag.sx
  const dy = e.screenY - drag.sy
  if (dx * dx + dy * dy >= CLICK_SQ) drag.moved = true
  const { ox, oy } = state.screen
  state.x = clamp(drag.winX + dx, ox, ox + state.screen.w - state.w)
  state.y = clamp(drag.winY + dy, oy, oy + state.screen.h - state.w)
  if (api) api.moveWindow({ x: Math.round(state.x), y: Math.round(state.y), animate: false }).catch(() => {})
  drag.lx = e.screenX; drag.ly = e.screenY
}
async function onPointerUp(e, allowed) {
  if (!drag || !drag.active) return
  const wasClick = !drag.moved
  drag.active = false
  $root.classList.remove('d-drag')
  pressUp()
  try { if (body.releasePointerCapture) body.releasePointerCapture(e.pointerId) } catch (err) {}

  if (allowed && wasClick) { refresh(true); return }

  let left = clamp(state.x, state.screen.ox, state.screen.ox + state.screen.w - state.w)
  let top = clamp(state.y, state.screen.oy, state.screen.oy + state.screen.h - state.w)
  const centerX = left + state.w / 2
  const centerY = top + state.w / 2
  const my = { left: state.screen.ox, right: state.screen.ox + state.screen.w, top: state.screen.oy, bottom: state.screen.oy + state.screen.h }
  if (centerX < my.left + state.screen.w / 4) { state.h = 'left'; state.hOff = 0 }
  else if (centerX > my.right - state.screen.w / 4) { state.h = 'right'; state.hOff = 0 }
  else { state.h = null; state.x = left }
  if (centerY < my.top + state.screen.h / 4) { state.v = 'top'; state.vOff = 0 }
  else if (centerY > my.bottom - state.screen.h / 4) { state.v = 'bottom'; state.vOff = 0 }
  else { state.v = null; state.y = top }

  await reflectWin(true)
}

body.addEventListener('pointerdown', onPointerDown)
body.addEventListener('pointermove', onPointerMove)
body.addEventListener('pointerup', e => onPointerUp(e, true))
body.addEventListener('pointercancel', e => onPointerUp(e, false))
window.addEventListener('resize', () => { reflectWin(false) })

async function boot() {
  try { const s = await api.getScreen(); state.screen.w = s.width; state.screen.h = s.height; state.screen.ox = s.x || 0; state.screen.oy = s.y || 0 } catch (e) {}
  try { const b = await api.getWinBounds(); if (b) { state.x = b.x; state.y = b.y; state.w = b.width; state.scale = clampScale(b.width / BASE) } } catch (e) {}
  img.src = 'DSniang02.png'
  $root.style.setProperty('--w', state.w + 'px')
  render()
  refresh(false)
  setInterval(() => refresh(false), REFRESH_MS)
}
boot()

window.__whaleProbe = {
  get state() {
    return {
      scale: state.scale, h: state.h, v: state.v, hOff: state.hOff, vOff: state.vOff,
      x: state.x, y: state.y, w: state.w, screen: Object.assign({}, state.screen),
      balance: state.balance, currency: state.currency,
      status: state.status, message: state.message, shown,
    }
  },
  get dom() {
    return {
      rootH: $root.getBoundingClientRect().height,
      imgNatural: img.naturalWidth, imgRectH: img.getBoundingClientRect().height,
      hasSizeBox: sizeBox.children.length,
      sizeBtnText: Array.prototype.map.call(sizeBox.children, b => b.textContent).join(','),
      label: labelEl.textContent, amount: amountEl.textContent, hint: hintEl.textContent,
    }
  },
}
