    "use strict"

    // ===================================================================
    //  DeepSeek 小鲸鱼余额挂件 —— Electron 主进程 (3.0.1)
    //  严格 1:1 复刻原版 DSH 插件 whale-balance.mjs 的全部功能，绝不改动原功能。
    //  仅增加「常驻桌面」必需的宿主外壳：
    //   · 透明置顶无边框浮窗，常驻桌面
    //   · 全程置顶可操作（游戏/窗口化全屏下也尽量维持在顶 + 越界兜底防跑丢）
    //   · 托盘（隐藏 / 显示 / 退出）
    //  以及与常驻相关的 bug 修复：
    //   · 拖拽窗口无限放大（setBounds 锁定边长，杜绝 DPI 换算累加）
    //   · 点击无法刷新（force 跳过 25s 缓存 + busy 时补刷）
    // ===================================================================

    const { app, BrowserWindow, ipcMain, screen, Tray, Menu, nativeImage } = require('electron')
    const path = require('path')
    const fs = require('fs')
    const os = require('os')

    const BALANCE_URL = 'https://api.deepseek.com/user/balance'
    const BALANCE_TTL_MS = 25000

    // ---------------- 密钥读取（与原插件一致：env → %USERPROFILE%\.dsh → $DSH_HOME） ----------------
    function resolveCredDirs() {
      const dirs = []
      const home = process.env.DSH_HOME
      if (home && home !== process.env.USERPROFILE) dirs.push(home)
      dirs.push(path.join(os.homedir(), '.dsh'))
      return Array.from(new Set(dirs))
    }
    function getApiKey() {
      if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY
      for (const dir of resolveCredDirs()) {
        const file = path.join(dir, '.credentials.yaml')
        try {
          if (!fs.existsSync(file)) continue
          for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
            const m = line.match(/^\s*DEEPSEEK_API_KEY\s*:\s*(?:"([^"]*)"|'([^']*)'|([^\s#]+))/)
            if (m) { const v = (m[1] || m[2] || m[3]).trim(); if (v) return v }
          }
        } catch (e) {}
      }
      return null
    }

    // ---------------- 余额查询（复刻原插件：重试 + 25s 缓存 + in-flight 去重 + 瞬断沿用旧值） ----------------
    let balanceCache = null
    let balanceInFlight = null

    async function fetchBalanceRaw(key) {
      let lastErr = null
      for (let attempt = 0; attempt < 2; attempt++) {
        let res
        try {
          res = await fetch(BALANCE_URL, {
            headers: { Authorization: 'Bearer ' + key },
            signal: AbortSignal.timeout(20000),
          })
        } catch (err) { lastErr = err; if (attempt === 0) await new Promise(r => setTimeout(r, 500)); continue }
        if (!res.ok) { lastErr = new Error('HTTP ' + res.status); if (res.status < 500) break; if (attempt === 0) await new Promise(r => setTimeout(r, 500)); continue }
        let data
        try { data = await res.json() } catch (e) { return { ok: false, code: 'PARSE', error: '返回不是合法 JSON' } }
        const info = data && Array.isArray(data.balance_infos) ? data.balance_infos[0] : null
        if (!info || info.total_balance === undefined) return { ok: false, code: 'SHAPE', error: '接口结构异常' }
        return { ok: true, totalBalance: Number(info.total_balance), currency: String(info.currency || 'CNY'), updatedAt: new Date().toISOString() }
      }
      const transient = !(lastErr && /^HTTP 4\d\d/.test(lastErr.message))
      return { ok: false, code: 'HTTP', transient, error: '请求失败: ' + String((lastErr && lastErr.message) || lastErr).slice(0, 200) }
    }

    async function getBalance(force) {
      const now = Date.now()
      if (!force && balanceCache && now - balanceCache.at < BALANCE_TTL_MS) return balanceCache.payload
      if (balanceInFlight) return balanceInFlight
      const key = getApiKey()
      if (!key) return { ok: false, code: 'NO_KEY', error: '未配置 DEEPSEEK_API_KEY' }
      balanceInFlight = (async () => {
        const payload = await fetchBalanceRaw(key)
        if (payload.ok) { balanceCache = { at: now, payload }; return payload }
        if (payload.transient && balanceCache) return { ...balanceCache.payload, stale: true, error: payload.error }
        if (!payload.transient) console.error('[whale]', payload.code, payload.error)
        return payload
      })().finally(() => { balanceInFlight = null })
      return balanceInFlight
    }

    // ---------------- 尺寸持久化（与原插件 .dshw-size.json 语义一致） ----------------
    const sizeFile = () => path.join(app.getPath('userData'), 'dshw-size.json')
    function readSize() {
      try {
        const p = sizeFile()
        if (!fs.existsSync(p)) return null
        const d = JSON.parse(fs.readFileSync(p, 'utf8'))
        if (d && typeof d.scale === 'number') return { scale: d.scale }
      } catch (e) {}
      return null
    }
    function writeSize(scale) {
      try {
        const body = JSON.stringify({ scale, updatedAt: new Date().toISOString() })
        fs.mkdirSync(path.dirname(sizeFile()), { recursive: true })
        fs.writeFileSync(sizeFile(), body, 'utf8')
        return { ok: true, scale }
      } catch (e) { return { ok: false, error: '无法持久化挂件尺寸' } }
    }

    // ---------------- 窗口 ----------------
    const BASE = 196
    const MIN_SCALE = 0.6
    const MAX_SCALE = 1.4
    const clampScale = s => Math.max(MIN_SCALE, Math.min(MAX_SCALE, s))

    let win = null
    let tray = null
    let curSize = Math.round(BASE)

    function createWindow() {
      const persisted = readSize()
      const scale = clampScale(persisted ? persisted.scale : 1)
      const size = Math.round(BASE * scale)
      curSize = size
      const wa = screen.getPrimaryDisplay().workArea
      const startX = wa.x + wa.width - size - 20
      const startY = wa.y + wa.height - size - 20

      win = new BrowserWindow({
        width: size,
        height: size,
        x: startX,
        y: startY,
        transparent: true,
        frame: false,
        resizable: false,
        fullscreenable: false,
        alwaysOnTop: true,
        skipTaskbar: true,
        hasShadow: false,
        focusable: true,
        webPreferences: {
          preload: path.join(__dirname, 'preload.js'),
          contextIsolation: true,
          nodeIntegration: false,
        },
      })
      win.setAlwaysOnTop(true, 'screen-saver')
      win.loadFile(path.join(__dirname, 'index.html'))
      win.on('closed', () => { win = null })
    }

    // ---------------- 全程置顶 + 越界兜底 ----------------
    function reinforceAlwaysOnTop() {
      if (!win || !win.isVisible || !win.isVisible()) return
      try {
        if (!win.isAlwaysOnTop()) win.setAlwaysOnTop(true, 'screen-saver')
      } catch (e) {}
      try {
        const b = win.getBounds()
        const d = screen.getDisplayMatching(b)
        const wa = d.workArea
        const clamped = {
          x: Math.min(Math.max(b.x, wa.x), wa.x + wa.width - b.width),
          y: Math.min(Math.max(b.y, wa.y), wa.y + wa.height - b.height),
        }
        if (clamped.x !== b.x || clamped.y !== b.y) {
          win.setBounds({ x: clamped.x, y: clamped.y, width: curSize, height: curSize })
        }
      } catch (e) {}
    }

    // ---------------- IPC ----------------
    ipcMain.handle('get-balance', (e, force) => getBalance(!!force))
    ipcMain.handle('get-screen', () => {
      const wa = screen.getPrimaryDisplay().workArea
      return { x: wa.x, y: wa.y, width: wa.width, height: wa.height }
    })
    ipcMain.handle('get-size', () => readSize() || {})
    ipcMain.handle('set-size', (e, s) => { const sc = clampScale(s); curSize = Math.round(BASE * sc); return writeSize(sc) })
    ipcMain.handle('get-win-bounds', () => (win ? Object.assign({}, win.getBounds()) : null))

    let animTimer = null
    ipcMain.handle('move-window', (e, { x, y, animate }) => {
      if (!win) return
      const keepBounds = (px, py) => {
        win.setBounds({ x: Math.round(px), y: Math.round(py), width: curSize, height: curSize })
      }
      if (animate) {
        if (animTimer) clearInterval(animTimer)
        const from = win.getBounds()
        const start = Date.now(); const dur = 180
        animTimer = setInterval(() => {
          if (!win) { clearInterval(animTimer); return }
          const t = Math.min(1, (Date.now() - start) / dur)
          const k = 1 - Math.pow(1 - t, 3)
          keepBounds(from.x + (x - from.x) * k, from.y + (y - from.y) * k)
          if (t >= 1) clearInterval(animTimer)
        }, 8)
      } else {
        keepBounds(x, y)
      }
    })
    ipcMain.handle('set-win-size', (e, { w, h }) => {
      if (!win) return
      curSize = Math.round(w)
      const b = win.getBounds()
      win.setBounds({ width: Math.round(w), height: Math.round(h), x: Math.round(b.x + (b.width - w) / 2), y: Math.round(b.y + (b.height - h) / 2) })
    })
    ipcMain.handle('quit-app', () => app.quit())

    // ---------------- 托盘 ----------------
    function setupTray() {
      let iconPath = path.join(__dirname, 'DSniang02.png')
      let img = nativeImage.createFromPath(iconPath)
      try { img = img.resize({ width: 16, height: 16 }) } catch (e) {}
      tray = new Tray(img)
      tray.setToolTip('DeepSeek 小鲸鱼余额')
      tray.setContextMenu(Menu.buildFromTemplate([
        { label: '显示 / 隐藏', click: () => { if (!win) return; win.isVisible() ? win.hide() : win.show() } },
        { label: '退出', click: () => app.quit() },
      ]))
      tray.on('click', () => { if (win) { win.isVisible() ? win.hide() : win.show() } })
    }

    // ---------------- 生命周期 ----------------
    const gotLock = app.requestSingleInstanceLock()
    if (!gotLock) {
      app.quit()
    } else {
      app.on('second-instance', () => { if (win) { win.show(); win.focus() } })
      app.whenReady().then(() => {
        createWindow()
        setupTray()
        setInterval(reinforceAlwaysOnTop, 2000)
        app.on('activate', () => { if (win === null) createWindow() })
      })
      app.on('window-all-closed', () => { /* 常驻：不退出，靠托盘 */ })
      app.on('before-quit', () => { if (tray) tray.destroy() })
    }
