'use strict'
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('whaleApi', {
  getBalance: (force) => ipcRenderer.invoke('get-balance', force),
  getScreen: () => ipcRenderer.invoke('get-screen'),
  getSize: () => ipcRenderer.invoke('get-size'),
  setSize: (s) => ipcRenderer.invoke('set-size', s),
  getWinBounds: () => ipcRenderer.invoke('get-win-bounds'),
  moveWindow: (o) => ipcRenderer.invoke('move-window', o),
  setWinSize: (o) => ipcRenderer.invoke('set-win-size', o),
  quit: () => ipcRenderer.invoke('quit-app'),
})
