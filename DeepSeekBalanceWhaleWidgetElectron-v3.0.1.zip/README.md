# DeepSeek 小鲸鱼余额挂件 · 3.0.1 源码

以**原版 DSH 插件** `DeepSeek-Balance-Whale-Widget-1.0.0`（`whale-balance.mjs`）为基线，
用 Electron 重做成独立桌面 exe。**严格 1:1 保留原插件全部功能，不改动任何原功能**；
仅增加「常驻桌面」必需的宿主外壳与 bug 修复。

## 目录

- `原始插件源码\`：主人提供的原版 DSH 插件（whale-balance.mjs / DSniang02.png / INSTALL.md 等），**保持原样未动**
- `DeepSeek-Balance-Whale-Widget-1.0.0.zip`：原版插件 zip
- `main.js`：Electron 主进程（密钥/余额查询/窗口置顶/托盘/IPC）
- `preload.js`：最小桥接 API
- `renderer.js`：严格复刻原插件 WIDGET_JS 的全部交互
- `index.html`：挂载页（html/body/#root 100% 高，防透明塌缩）
- `package.json`：依赖与 electron-builder 打包配置

## 构建说明

参见 `build\whale-workspace\`（完整可复现构建环境，含 node_modules/electron dist）。

```powershell
# 在 build\whale-workspace\ 下
$env:ELECTRON_SKIP_BINARY_DOWNLOAD = "1"
bun install                              # 装依赖（跳过 electron 二进制自动下载）
# 手动获取 electron 二进制（本机用华为云最快）：
Invoke-WebRequest -Uri "https://mirrors.huaweicloud.com/electron/31.7.7/electron-v31.7.7-win32-x64.zip" -OutFile electron.zip
Expand-Archive electron.zip -DestinationPath node_modules/electron/dist -Force
Set-Content node_modules/electron/path.txt "electron.exe" -NoNewline
bun x electron-builder --win portable    # 打包
# 产物：release/DeepSeek小鲸鱼余额-3.0.1-portable.exe
```

> 重要：本机有系统级环境变量 `ELECTRON_RUN_AS_NODE=1`，运行/打包前务必
> `Remove-Item Env:ELECTRON_RUN_AS_NODE`，否则 electron 以 node 模式跑会崩。
> 若 electron-builder 报 `No JSON content found`，删掉 yarn.lock 再打。

## 与原插件的一致性

未改动原功能的任何行为；数据源仅从插件 HTTP 路由换成 Electron IPC，交互逻辑逐行对齐原版 WIDGET_JS。
新增项均为**常驻桌面必需**（透明置顶窗口、托盘、全程置顶可操作）及**已确认的 bug 修复**，
无任何插件之外的多余功能。
